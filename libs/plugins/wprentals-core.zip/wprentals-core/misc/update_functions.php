<?php
/**
 * Update functions used to update various data from old theme version to new theme versions.
 * 
 * 
 */
