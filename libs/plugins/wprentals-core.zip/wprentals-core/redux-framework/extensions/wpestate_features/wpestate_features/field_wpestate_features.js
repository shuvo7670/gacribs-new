/* global confirm, redux, redux_change */

jQuery(document).ready(function() {

  
});
